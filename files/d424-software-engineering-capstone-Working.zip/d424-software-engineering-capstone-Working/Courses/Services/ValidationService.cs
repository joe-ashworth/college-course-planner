﻿using System.Text.RegularExpressions;

namespace Courses.Services
{
    public static class ValidationService
    {
        public static bool IsValidUsername(string username)
        {
            if (string.IsNullOrWhiteSpace(username))
            {
                return false;
            }

            if (username.Length < 3)
            {
                return false;
            }
            if (username.Contains(" "))
            {
                return false;
            }

            return true;
        }
        public static bool IsValidPassword(string password)
        {
            if (string.IsNullOrWhiteSpace(password))
            {
                return false;
            }
            if (password.Length < 3)
            {
                return false;
            }
            if (password.Contains(" "))
            {
                return false;
            }
            return true;
        }
        public static bool IsValidTitle(string title)
        {
            if (string.IsNullOrWhiteSpace(title))
            {
                return false;
            }

            if (title.Length < 3 || title.Length > 100)
            {
                return false;
            }

            // Only letters, numbers, spaces, and basic punctuation)
            if (!Regex.IsMatch(title, @"^[a-zA-Z0-9\s\.,'-]+$"))
            {
                return false;
            }

            return true;
        }
        public static bool IsValidName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
            {
                return false;
            }

            // Only letters and spaces
            if (!Regex.IsMatch(name, @"^[a-zA-Z\s]+$"))
            {
                return false;
            }

            return true;
        }
        public static bool IsValidPhone(string phone)
        {
            if (string.IsNullOrWhiteSpace(phone))
            {
                return false;
            }

            // Only allow numbers, dashes, periods, pluses, spaces, and parentheses
            if (!Regex.IsMatch(phone, @"^[0-9\-\.\+\s\(\)]+$"))
            {
                return false;
            }

            return true;
        }
        public static bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                return false;
            }

            // Regular expression for validating email addresses
            string emailPattern = @"^[^@\s]+@[^@\s]+\.[^@\s]+$";

            if (!Regex.IsMatch(email, emailPattern))
            {
                return false;
            }

            return true;
        }
    }
}
