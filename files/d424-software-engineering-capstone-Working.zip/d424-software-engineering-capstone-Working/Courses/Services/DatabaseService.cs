﻿using SQLite; // All CRUD operations performed on SQLiteAsyncConnection
using Courses.Models;

namespace Courses.Services
{
    public static class DatabaseService
    {
        private static SQLiteAsyncConnection? _db;
        static async Task Init()
        {
            if (_db != null)
            {
                return;
            }
            else
            {
                await SetupDatabase();
            }
        }


        #region Loads and Resets

        public static async Task SetupDatabase()
        {
            if (_db != null)
            {
                return;
            }

            var databasePath = Path.Combine(FileSystem.AppDataDirectory, "Courses.db");

            _db = new SQLiteAsyncConnection(databasePath);

            await _db.CreateTableAsync<User>();
            await _db.CreateTableAsync<Term>();
            await _db.CreateTableAsync<Course>();
            await _db.CreateTableAsync<Assessment>();
            await _db.CreateTableAsync<Status>();

            // Check if statuses already exist
            var existingStatuses = await _db.Table<Status>().ToListAsync();
            if (!existingStatuses.Any())
            {
                // Insert statuses
                var statuses = new List<Status>
                {
                    new Status { Name = "Plan to Take" },
                    new Status { Name = "In Progress" },
                    new Status { Name = "Completed" },
                    new Status { Name = "Dropped" }
                };
                foreach (var status in statuses)
                {
                    await InsertStatusAsync(status);
                }
            }
        }

        public static async Task LoadSampleData()
        {
            await Init();

            Term term = new()
            {
                Title = "Fall 2024 Term",
                StartDate = new DateTime(2024, 9, 1),
                EndDate = new DateTime(2025, 2, 28),
            };
            await _db.InsertAsync(term);


            Course course = new()
            {
                Title = "Intro to Data Entry",
                Status = "Plan to Take",
                InstructorsName = "Anika Patel",
                InstructorsPhone = "555-123-4567",
                InstructorsEmail = "anikapatel@strimeuniversity.edu",
                StartDate = new DateTime(2024, 9, 1),
                EndDate = new DateTime(2024, 9, 30),
                StartNotification = true,
                EndNotification = true,
                TermId = term.Id,
                Notes = "This course explores several common data entry methods.",
                CreationDate = DateTime.Now
            };
            await _db.InsertAsync(course);

            Assessment assessment1 = new()
            {
                Title = "Data Entry Project: DEP1",
                Type = "Objective Assessment",
                DueDate = new DateTime(2024, 9, 30),
                StartDate = new DateTime(2024, 9, 17),
                EndDate = new DateTime(2024, 9, 30),
                StartNotification = false,
                EndNotification = false,
                Notes = "This data entry project requires an Excel spreadsheet.",
                CourseId = course.Id
            };
            await _db.InsertAsync(assessment1);

            Assessment assessment2 = new()
            {
                Title = "Data Entry Exam: DEE1",
                Type = "Performance Assessment",
                DueDate = new DateTime(2024, 9, 30),
                StartDate = new DateTime(2024, 9, 17),
                EndDate = new DateTime(2024, 9, 30),
                StartNotification = false,
                EndNotification = false,
                Notes = "This data entry exam tests the student's knowledge of various data entry methods.",
                CourseId = course.Id
            };
            await _db.InsertAsync(assessment2);


            Term term2 = new()
            {
                Title = "Spring 2025 Term",
                StartDate = new DateTime(2025, 3, 1),
                EndDate = new DateTime(2025, 8, 30),
            };
            await _db.InsertAsync(term2);


            Course course2 = new()
            {
                Title = "Advanced Data Entry",
                Status = "Plan to Take",
                InstructorsName = "Anika Patel",
                InstructorsPhone = "555-123-4567",
                InstructorsEmail = "anikapatel@strimeuniversity.edu",
                StartDate = new DateTime(2025, 3, 1),
                EndDate = new DateTime(2025, 3, 15),
                StartNotification = true,
                EndNotification = true,
                TermId = term2.Id,
                Notes = "This course explores advanced data entry methods.",
                CreationDate = DateTime.Now
            };
            await _db.InsertAsync(course2);

            Assessment assessment3 = new()
            {
                Title = "Data Entry Exam: DEE1",
                Type = "Performance Assessment",
                DueDate = new DateTime(2025, 3, 15),
                StartDate = new DateTime(2024, 3, 1),
                EndDate = new DateTime(2024, 3, 15),
                StartNotification = false,
                EndNotification = false,
                Notes = "This data entry exam tests the student's knowledge of advanced data entry methods.",
                CourseId = course2.Id
            };
            await _db.InsertAsync(assessment3);



            //Settings.FirstRun = false;

        }

        // Reset the application to its initial state
        public static async Task ResetApplication()
        {
            await Init();

            await _db.DropTableAsync<User>();
            await _db.DropTableAsync<Term>();
            await _db.DropTableAsync<Course>();
            await _db.DropTableAsync<Assessment>();
            await _db.DropTableAsync<Status>();

            _db = null;

            //Settings.ClearSettings();
            await SetupDatabase();
        }

        public static async Task ClearSampleData()
        {
            await Init();

            await _db.DropTableAsync<User>();
            await _db.DropTableAsync<Term>();
            await _db.DropTableAsync<Course>();
            await _db.DropTableAsync<Assessment>();

            _db = null;

            Settings.ClearSettings();
        }

        // Empty all user input data
        public static async Task ClearAllData()
        {
            await Init();

            await _db.DropTableAsync<User>();
            await _db.DropTableAsync<Term>();
            await _db.DropTableAsync<Course>();
            await _db.DropTableAsync<Assessment>();

            await _db.CreateTableAsync<User>();
            await _db.CreateTableAsync<Term>();
            await _db.CreateTableAsync<Course>();
            await _db.CreateTableAsync<Assessment>();
        }

        

        #endregion

        

        #region User methods
        public static async Task<User> GetUserAsync(string username, string password)
        {
            await Init();

            var user = await _db.Table<User>()
                    .Where(u => u.Username == username && u.Password == password)
                    .FirstOrDefaultAsync();

            return user;
        }

        public static async Task<int> SaveUserAsync(User user)
        {
            return await _db.InsertAsync(user);
        }

        public static async Task AddUser(string username, string password)
        {
            await Init();

            var user = new User()
            {
                Username = username,
                Password = password,
            };

            await _db.InsertAsync(user);
        }

        public static async Task<bool> UserExistsAsync(string username)
        {
            await Init();

            var user = await _db.Table<User>().Where(u => u.Username == username).FirstOrDefaultAsync();
            return user != null;
        }

        #endregion


        #region Terms methods

        public static async Task RemoveTerm(int id)
        {
            await Init();

            await _db.DeleteAsync<Term>(id);
        }
        public static async Task<IEnumerable<Term>> GetTerms()
        {
            await Init();

            var terms = await _db.Table<Term>().ToListAsync();
            return terms;
        }
        public static async Task<int> GetCourseCount()
        {
            return await _db.Table<Course>().CountAsync();
        }

        #endregion


        #region Courses methods

        public static async Task RemoveCourse(int id)
        {
            await Init();

            await _db.DeleteAsync<Course>(id);
        }

        public static async Task<IEnumerable<Course>> GetCourses(string searchString)
        {
            await Init();

            var courses = await _db.Table<Course>()
                .Where(c => c.Title.ToLower().Contains(searchString.ToLower()))
                .ToListAsync();

            return courses;
        }

        public static async Task<IEnumerable<Course>> GetCourses(int termId)
        {
            await Init();

            var courses = await _db.Table<Course>().Where(i => i.TermId == termId).ToListAsync();
            return courses;
        }
        public static async Task<IEnumerable<Course>> GetCourses()
        {
            await Init();

            var courses = await _db.Table<Course>().ToListAsync();
            return courses;
        }

        #endregion


        #region Assessments methods

        public static async Task RemoveAssessment(int id)
        {
            await Init();

            await _db.DeleteAsync<Assessment>(id);
        }
        public static async Task<IEnumerable<Assessment>> GetAssessments(int courseId)
        {
            await Init();

            var assessments = await _db.Table<Assessment>().Where(i => i.CourseId == courseId).ToListAsync();
            return assessments;
        }
        public static async Task<IEnumerable<Assessment>> GetAssessments()
        {
            await Init();

            var assessments = await _db.Table<Assessment>().ToListAsync();
            return assessments;
        }


        #endregion


        #region Status methods

        public static async Task<IEnumerable<string>> GetStatusOptionsAsync()
        {
            await Init();
            var statuses = await _db.Table<Status>().ToListAsync();
            return statuses.Select(s => s.Name);
        }

        public static async Task<int> InsertStatusAsync(Status status)
        {
            await Init();
            return await _db.InsertAsync(status);
        }

        #endregion


        


        #region Count Rows

        public static async Task<int> GetCourseCountAsync(int selectedTermId)
        {
            await Init();

            // Use parameterized query to prevent SQL injection
            int courseCount = await _db.ExecuteScalarAsync<int>("SELECT COUNT(*) FROM Course WHERE TermId = ?", selectedTermId);
            return courseCount;
        }

        public static async Task<int> GetAssessmentCountAsync(int selectedCourseId)
        {
            int assessmentCount = await _db.ExecuteScalarAsync<int>($"Select Count(*) from Assessment where CourseId= ?", selectedCourseId);

            return assessmentCount;
        }

        #endregion


        #region Inserts and Updates

        public static async Task<int> InsertEntityAsync<T>(T entity) where T : Entity
        {
            await Init();
            return await _db.InsertAsync(entity);
        }

        public static async Task UpdateEntityAsync<T>(T entity) where T : Entity, new()
        {
            await Init();

            var existingEntity = await _db.Table<T>()
                .Where(i => i.Id == entity.Id)
                .FirstOrDefaultAsync();

            if (existingEntity != null)
            {
                await _db.UpdateAsync(entity);
            }
        }

        #endregion
    }
}
