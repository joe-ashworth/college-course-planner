﻿using System.Text;

namespace Courses.Services
{
    public static class LoginService
    {
        private static readonly string FilePath = Path.Combine(FileSystem.AppDataDirectory, "logins.txt");

        public static async Task SaveLoginRecordAsync(string username)
        {
            // Save each login record to a file with a timestamp
            string record = $"{DateTime.Now}: {username} logged in successfully{Environment.NewLine}";
            await File.AppendAllTextAsync(FilePath, record, Encoding.UTF8);
        }

        public static async Task<string> ReadLoginRecordsAsync()
        {
            if (File.Exists(FilePath))
            {
                return await File.ReadAllTextAsync(FilePath, Encoding.UTF8);
            }
            return string.Empty;
        }
    }
}
