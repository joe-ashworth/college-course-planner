﻿using SQLite;

public abstract class Entity
{
    [PrimaryKey, AutoIncrement]
    public int Id { get; set; }
}