﻿using SQLite;

namespace Courses.Models
{
    public class Assessment : Entity
    {
        public int CourseId { get; set; } // FK from Course
        public string Title { get; set; }
        public string Type { get; set; }
        public bool StartNotification { get; set; }
        public bool EndNotification { get; set; }
        public DateTime DueDate { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Notes { get; set; }
    }
}
