﻿namespace Courses.Models
{
    public class Status : Entity
    {
        public string? Name { get; set; }
    }
}