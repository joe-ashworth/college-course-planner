﻿using SQLite;

namespace Courses.Models
{
    public class Course : Entity
    {
        public int TermId { get; set; } // Foreign key from Term
        public string Title { get; set; }
        public string Status { get; set; }
        public string InstructorsName { get; set; }
        public string InstructorsPhone { get; set; }
        public string InstructorsEmail { get; set; }
        public bool StartNotification { get; set; }
        public bool EndNotification { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string? Notes { get; set; }
        public DateTime CreationDate { get; set; }
    }
}
