using System.Security.Cryptography;
using System.Text;
using Courses.Models;
using Courses.Services;

namespace Courses.Views;

public partial class LoginPage : ContentPage
{
    public event EventHandler LoginSuccessful;
    public LoginPage()
    {
        InitializeComponent();
    }

    private async void LoginButton_Clicked(object sender, EventArgs e)
    {
        string username = UsernameEntry.Text;
        string password = PasswordEntry.Text;

        if (!ValidationService.IsValidUsername(username))
        {
            await DisplayAlert("Invalid Username", "Username must be at least 3 characters long and cannot contain spaces.", "OK");
            return;
        }

        if (!ValidationService.IsValidPassword(password))
        {
            await DisplayAlert("Invalid Password", "Password must be at least 3 characters long and cannot contain spaces.", "OK");
            return;
        }

        string hashedPassword = HashPassword(password);

        User user = await DatabaseService.GetUserAsync(username, hashedPassword);

        if (user != null)
        {
            await DisplayAlert("Success", "User Validated.", "OK");
            await LoginService.SaveLoginRecordAsync(username);
            await Navigation.PopModalAsync();
        }
        else
        {
            await DisplayAlert("Login Failed", "Invalid credentials.", "OK");
        }
    }



    private async void RegisterButton_Clicked(object sender, EventArgs e)
    {
        string username = UsernameEntry.Text;
        string password = PasswordEntry.Text;

        if (!ValidationService.IsValidUsername(username))
        {
            await DisplayAlert("Invalid Username", "Username must be at least 3 characters long and cannot contain spaces.", "OK");
            return;
        }

        if (!ValidationService.IsValidPassword(password))
        {
            await DisplayAlert("Invalid Password", "Password must be at least 3 characters long and cannot contain spaces.", "OK");
            return;
        }

        bool userExists = await DatabaseService.UserExistsAsync(username);
        if (userExists)
        {
            await DisplayAlert("User Exists", "This username already exists. Please choose a different username.", "OK");
            return;
        }

        string hashedPassword = HashPassword(password);

        await DatabaseService.InsertEntityAsync(
            new User
            {
                Username = username,
                Password = hashedPassword
            }
        );

        UsernameEntry.Text = "";
        PasswordEntry.Text = "";

        await DisplayAlert("User added", "New user added.", "OK");
    }

    private async void ClearButton_Clicked(object sender, EventArgs e)
    {
        await DatabaseService.ClearAllData();
        await DisplayAlert("Content Cleared", "All data has been deleted.", "OK");
    }

    private string HashPassword(string password)
    {
        using (SHA256 sha256Hash = SHA256.Create())
        {
            byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(password));
            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < bytes.Length; i++)
            {
                builder.Append(bytes[i].ToString("x2"));
            }
            return builder.ToString();
        }
    }

    private async void ViewLoginRecordsLabel_Tapped(object sender, EventArgs e)
    {
        string loginRecords = await LoginService.ReadLoginRecordsAsync();
        LoginRecordsLabel.Text = loginRecords;
    }
}