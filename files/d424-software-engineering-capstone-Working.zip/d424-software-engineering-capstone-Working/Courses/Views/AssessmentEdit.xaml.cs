using Courses.Models;
using Courses.Services;

namespace Courses.Views;

public partial class AssessmentEdit : ContentPage
{
    private readonly int _courseId;
    private readonly int _selectedAssessmentId;

    public AssessmentEdit(int courseId)
    {
        InitializeComponent();
        _courseId = courseId;
    }

    public AssessmentEdit(Assessment selectedAssessment)
    {
        InitializeComponent();

        _selectedAssessmentId = selectedAssessment.Id;
        _courseId = selectedAssessment.CourseId;

        AssessmentId.Text = selectedAssessment.Id.ToString();
        AssessmentTitle.Text = selectedAssessment.Title;
        AssessmentTypePicker.SelectedItem = selectedAssessment.Type;
        if (selectedAssessment.Notes is not null)
        {
            NotesEditor.Text = selectedAssessment.Notes.ToString();
        }
        DueDatePicker.Date = selectedAssessment.DueDate;
        StartDatePicker.Date = selectedAssessment.StartDate;
        EndDatePicker.Date = selectedAssessment.EndDate;
        StartNotification.IsToggled = selectedAssessment.StartNotification;
        EndNotification.IsToggled = selectedAssessment.EndNotification;
    }

    async void SaveAssessment_Clicked(object sender, EventArgs e)
    {
        // Trim inputs
        string assessmentTitle = AssessmentTitle.Text?.Trim() ?? string.Empty;

        if (!ValidationService.IsValidTitle(assessmentTitle))
        {
            await DisplayAlert("Invalid Title", "Please enter a title.", "OK");
            return;
        }

        if (AssessmentTypePicker.SelectedIndex == -1)
        {
            await DisplayAlert("Missing Status", "Please enter a status.", "OK");
            return;
        }

        if (StartDatePicker.Date >= EndDatePicker.Date)
        {
            await DisplayAlert("Invalid Dates", "The start date must precede the end date.", "OK");
            return;
        }

        
        var assessment = new Assessment
        {
            Id = Int32.Parse(AssessmentId.Text),
            CourseId = _courseId,
            Title = AssessmentTitle.Text,
            Type = AssessmentTypePicker.SelectedItem.ToString(),
            DueDate = DueDatePicker.Date,
            StartDate = StartDatePicker.Date,
            EndDate = EndDatePicker.Date,
            StartNotification = StartNotification.IsToggled,
            EndNotification = EndNotification.IsToggled,
            Notes = NotesEditor.Text
        };

        await DatabaseService.UpdateEntityAsync(assessment);

        await Navigation.PopAsync();
    }

    private async void CancelAssessment_Clicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    private async void DeleteAssessment_Clicked(object sender, EventArgs e)
    {
        var answer = await DisplayAlert("Delete?", "Delete this Assessment?", "Yes", "No");

        if (answer == true)
        {
            var id = int.Parse(AssessmentId.Text);
            await DatabaseService.RemoveAssessment(id);
        }

        await Navigation.PopAsync();
    }
}