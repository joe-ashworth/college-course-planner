using Courses.Services;
using Courses.Models;

namespace Courses.Views;

public partial class AssessmentAdd : ContentPage
{
    private readonly int _selectedCourseId;

    public AssessmentAdd()
    {
        InitializeComponent();
    }

    public AssessmentAdd(int courseId)
    {
        InitializeComponent();
        _selectedCourseId = courseId;
    }

    async void SaveAssessment_Clicked(object sender, EventArgs e)
    {
        // Trim inputs
        string assessmentTitle = AssessmentTitle.Text?.Trim() ?? string.Empty;

        int currentCount = await DatabaseService.GetAssessmentCountAsync(_selectedCourseId); // Should not be necessary
        if (currentCount >= 2)
        {
            await DisplayAlert("Maximum Assessments Reached", "Only 2 assessments are allowed per course.", "OK");
            return;
        }

        if (!ValidationService.IsValidTitle(assessmentTitle))
        {
            await DisplayAlert("Missing or Invalid Title", "Please enter a valid title.", "OK");
            return;
        }

        if (AssessmentTypePicker.SelectedIndex == -1)
        {
            await DisplayAlert("Missing Type", "Please select an assessment type.", "OK");
            return;
        }

        await DatabaseService.InsertEntityAsync(
            new Assessment
            {
                CourseId = _selectedCourseId,
                Title = assessmentTitle,
                Type = AssessmentTypePicker.SelectedItem.ToString(),
                DueDate = EndDatePicker.Date,
                StartDate = StartDatePicker.Date,
                EndDate = EndDatePicker.Date,
                StartNotification = StartNotification.IsToggled,
                EndNotification = EndNotification.IsToggled,
                Notes = NotesEditor.Text,
            }
        );

        await Navigation.PopAsync();
    }

    private async void CancelAssessment_Clicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    private async void Home_Clicked(object sender, EventArgs e)
    {
        await Navigation.PopToRootAsync();
    }
}