using Courses.Services;
using Courses.Models;

namespace Courses.Views;

public partial class TermEdit : ContentPage
{
    private readonly int _selectedTermId;

    public TermEdit()
    {
        InitializeComponent();
    }
    public TermEdit(Term term)
    {
        InitializeComponent();

        _selectedTermId = term.Id;

        TermId.Text = term.Id.ToString();
        TermTitle.Text = term.Title;
        StartDatePicker.Date = term.StartDate;
        EndDatePicker.Date = term.EndDate;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        // Count courses in the specified term.
        int countCourses = await DatabaseService.GetCourseCountAsync(_selectedTermId);

        // Display number of currently assigned courses.
        CountLabel.Text = countCourses.ToString() + " courses in this term (6 max).";

        // Render courses for the specified Term
        CourseCollectionView.ItemsSource = await DatabaseService.GetCourses(_selectedTermId);

        // Only show "Add Course" button when fewer than 6 exist
        AddCourse.IsVisible = countCourses < 6;
    }


    private async void SaveTerm_Clicked(object sender, EventArgs e)
    {
        // Trim inputs
        string termTitle = TermTitle.Text?.Trim() ?? string.Empty;

        if (!ValidationService.IsValidTitle(termTitle))
        {
            await DisplayAlert("Missing Title", "Please give the term a title.", "OK");
            return;
        }

        if (StartDatePicker.Date >= EndDatePicker.Date)
        {
            await DisplayAlert("Invalid Dates", "The start date must precede the end date.", "OK");
            return;
        }

        var term = new Term
        {
            Id = Int32.Parse(TermId.Text),
            Title = termTitle,
            StartDate = StartDatePicker.Date,
            EndDate = EndDatePicker.Date
        };
        await DatabaseService.UpdateEntityAsync(term);

        await Navigation.PopAsync();
    }

    private async void CancelTerm_Clicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    private async void DeleteTerm_Clicked(object sender, EventArgs e)
    {
        var answer = await DisplayAlert("Delete Term and Related Courses?", "Delete this Term?", "Yes", "No");
        if (answer == true)
        {
            var id = int.Parse(TermId.Text);
            await DatabaseService.RemoveTerm(id);
        }
        else
        {
            await DisplayAlert("Canceled", "Deletion Canceled", "OK");
        }

        await Navigation.PopAsync();
    }

    private async void AddCourse_Clicked(object sender, EventArgs e)
    {
        var termId = Int32.Parse(TermId.Text);

        await Navigation.PushAsync(new CourseAdd(termId));
    }

    private async void CourseCollectionView_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        var course = e.CurrentSelection.FirstOrDefault() as Course;
        if (course != null)
        {
            await Navigation.PushAsync(new CourseEdit(course));
        }
    }

    private bool _isElementVisible;
    public bool IsElementVisible
    {
        get => _isElementVisible;
        set
        {
            if (_isElementVisible != value)
            {
                _isElementVisible = value;
                OnPropertyChanged(); // Notify UI of change
            }
        }
    }
}