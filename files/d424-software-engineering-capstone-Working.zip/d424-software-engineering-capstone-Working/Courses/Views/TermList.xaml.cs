using Courses.Models;
using Courses.Services;
using Plugin.LocalNotification;

namespace Courses.Views;

public partial class TermList : ContentPage
{
    private static DateTime _lastNotificationTime;
    public TermList()
	{
		InitializeComponent();
	}

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        //if (Settings.FirstRun)
        //{
        //    await DatabaseService.LoadSampleData();

        //    Settings.FirstRun = false;
        //}

        await RefreshTermCollectionView();

        if (DateTime.Now - _lastNotificationTime < TimeSpan.FromDays(1))
        {
            return; // Exit if notifications were already shown today.
        }
        _lastNotificationTime = DateTime.Now;

        ShowCourseNotifications();
        ShowAssessmentNotifications();
    }

    async void AddTerm_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new TermAdd());
    }
    async void Search_Clicked(object sender, EventArgs e)
    {
        await Navigation.PushAsync(new Search());
    }

    private async void ClearDatabase_Clicked(object sender, EventArgs e)
    {
        var answer = await DisplayAlert("Reset Application?", "Are you sure you want to reset the application to its default state?", "Yes", "No");
        if (answer == true)
        {
            await DatabaseService.ResetApplication();
            await RefreshTermCollectionView();
            await DisplayAlert("Application Reset", "The application has been reset.", "Ok");

            var loginPage = new LoginPage();
            await Navigation.PushModalAsync(loginPage);
        }
        
    }

    private async void LoadSampleData_Clicked(object sender, EventArgs e)
    {
        //if (Settings.FirstRun)
        //{
        //    await DatabaseService.LoadSampleData();
        //    await RefreshTermCollectionView();
        //}

        await DatabaseService.LoadSampleData();
        await RefreshTermCollectionView();

    }

    private async void TermCollectionView_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (e.CurrentSelection != null)
        {
            Term term = (Term)e.CurrentSelection.FirstOrDefault();
            await Navigation.PushAsync(new TermEdit(term));
        }
    }

    private async Task RefreshTermCollectionView()
    {
        TermCollectionView.ItemsSource = await DatabaseService.GetTerms();
        
    }

    private async void ShowCourseNotifications()
    {
        if (await LocalNotificationCenter.Current.AreNotificationsEnabled() == false)
        {
            await LocalNotificationCenter.Current.RequestNotificationPermission();
        }

        var courseList = await DatabaseService.GetCourses();
        var notifyRandom = new Random();

        foreach (Course courseRecord in courseList)
        {
            if (courseRecord.StartNotification == true)
            {
                if (courseRecord.StartDate == DateTime.Today)
                {
                    var notifyId = notifyRandom.Next(1000);

                    var notification = new NotificationRequest
                    {
                        NotificationId = notifyId,
                        Title = "Course Starts Today",
                        Subtitle = $"Update for Course: {courseRecord.Title}",
                        Description = $"Course: {courseRecord.Title} begins today!",
                        ReturningData = "Return Data",
                        BadgeNumber = 42,
                        Schedule = new NotificationRequestSchedule()
                        {
                            NotifyTime = DateTime.Now.AddSeconds(5),
                        }
                    };

                    await LocalNotificationCenter.Current.Show(notification);
                }
            }

            if (courseRecord.EndNotification == true)
            {
                if (courseRecord.EndDate == DateTime.Today)
                {
                    var notifyId = notifyRandom.Next(1000);

                    var notification = new NotificationRequest
                    {
                        NotificationId = notifyId,
                        Title = "Course Ends Today",
                        Subtitle = $"Update for Course: {courseRecord.Title}",
                        Description = $"Course: {courseRecord.Title} ends today!",
                        ReturningData = "Return Data",
                        BadgeNumber = 42,
                        Schedule = new NotificationRequestSchedule()
                        {
                            NotifyTime = DateTime.Now.AddSeconds(5),
                        }
                    };

                    await LocalNotificationCenter.Current.Show(notification);
                }
            }


        }
    }


    private async void ShowAssessmentNotifications()
    {
        if (await LocalNotificationCenter.Current.AreNotificationsEnabled() == false)
        {
            await LocalNotificationCenter.Current.RequestNotificationPermission();
        }

        var assessmentList = await DatabaseService.GetAssessments();
        var notifyRandom = new Random();

        foreach (Assessment assessmentRecord in assessmentList)
        {
            if (assessmentRecord.StartNotification == true)
            {
                if (assessmentRecord.StartDate == DateTime.Today)
                {
                    var notifyId = notifyRandom.Next(1000);

                    var notification = new NotificationRequest
                    {
                        NotificationId = notifyId,
                        Title = "Assessment Starts Today",
                        Subtitle = $"Update for Assessment: {assessmentRecord.Title}",
                        Description = $"Assessment: {assessmentRecord.Title} begins today!",
                        ReturningData = "Return Data",
                        BadgeNumber = 42,
                        Schedule = new NotificationRequestSchedule()
                        {
                            NotifyTime = DateTime.Now.AddSeconds(5),
                        }
                    };

                    await LocalNotificationCenter.Current.Show(notification);
                }
            }

            if (assessmentRecord.EndNotification == true)
            {
                if (assessmentRecord.EndDate == DateTime.Today)
                {
                    var notifyId = notifyRandom.Next(1000);

                    var notification = new NotificationRequest
                    {
                        NotificationId = notifyId,
                        Title = "Assessment Ends Today",
                        Subtitle = $"Update for Assessment: {assessmentRecord.Title}",
                        Description = $"Assessment: {assessmentRecord.Title} ends today!",
                        ReturningData = "Return Data",
                        BadgeNumber = 42,
                        Schedule = new NotificationRequestSchedule()
                        {
                            NotifyTime = DateTime.Now.AddSeconds(5),
                        }
                    };

                    await LocalNotificationCenter.Current.Show(notification);
                }
            }


        }
    }
}