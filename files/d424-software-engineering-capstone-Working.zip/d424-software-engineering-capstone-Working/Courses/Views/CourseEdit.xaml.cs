using Courses.Models;
using Courses.Services;

namespace Courses.Views;

public partial class CourseEdit : ContentPage
{
    private readonly int _selectedCourseId;
    private readonly int _parentTermId;

    public CourseEdit()
    {
        InitializeComponent();
    }
    public CourseEdit(Course selectedCourse)
    {
        InitializeComponent();

        _selectedCourseId = selectedCourse.Id;
        _parentTermId = selectedCourse.TermId;

        CourseId.Text = selectedCourse.Id.ToString();
        CourseTitle.Text = selectedCourse.Title;
        CourseStatusPicker.SelectedItem = selectedCourse.Status;
        InstructorsName.Text = selectedCourse.InstructorsName.ToString();
        InstructorsPhone.Text = selectedCourse.InstructorsPhone.ToString();
        InstructorsEmail.Text = selectedCourse.InstructorsEmail.ToString();
        if (selectedCourse.Notes is not null)
        {
            NotesEditor.Text = selectedCourse.Notes.ToString();
        }
        StartDatePicker.Date = selectedCourse.StartDate;
        EndDatePicker.Date = selectedCourse.EndDate;
        StartNotification.IsToggled = selectedCourse.StartNotification;
        EndNotification.IsToggled = selectedCourse.EndNotification;
    }

    protected override async void OnAppearing()
    {
        base.OnAppearing();

        // Count assessments in the specified course.
        int countAssessments = await DatabaseService.GetAssessmentCountAsync(_selectedCourseId);

        // Display number of currently assigned courses.
        CountLabel.Text = countAssessments.ToString() + " assessments in this course (2 max).";

        // Render courses for the specified Term
        AssessmentCollectionView.ItemsSource = await DatabaseService.GetAssessments(_selectedCourseId);

        // Only show "Add Course" button when fewer than 6 exist
        AddAssessment.IsVisible = countAssessments < 2;
    }

    async void SaveCourse_Clicked(object sender, EventArgs e)
    {
        // Trim inputs
        string courseTitle = CourseTitle.Text?.Trim() ?? string.Empty;
        string instructorsName = InstructorsName.Text?.Trim() ?? string.Empty;
        string instructorsPhone = InstructorsPhone.Text?.Trim() ?? string.Empty;
        string instructorsEmail = InstructorsEmail.Text?.Trim() ?? string.Empty;
        string notes = NotesEditor.Text?.Trim() ?? string.Empty;

        if (!ValidationService.IsValidTitle(courseTitle))
        {
            await DisplayAlert("Invalid Title", "Please enter a title.", "OK");
            return;
        }

        if (CourseStatusPicker.SelectedIndex == -1)
        {
            await DisplayAlert("Missing Status", "Please enter a status.", "OK");
            return;
        }

        if (StartDatePicker.Date >= EndDatePicker.Date)
        {
            await DisplayAlert("Invalid Dates", "The start date must precede the end date.", "OK");
            return;
        }

        if (!ValidationService.IsValidName(instructorsName))
        {
            await DisplayAlert("Invalid Instructor Name", "Please enter the instructor's name.", "OK");
            return;
        }

        if (!ValidationService.IsValidPhone(instructorsPhone))
        {
            await DisplayAlert("Invalid Phone", "Please enter instructor's phone number.", "OK");
            return;
        }

        if (!ValidationService.IsValidEmail(instructorsEmail))
        {
            await DisplayAlert("Invalid Email", "Please enter instructor's email address.", "OK");
            return;
        }

        var course = new Course
        {
            Id = Int32.Parse(CourseId.Text),
            TermId = _parentTermId,
            Title = CourseTitle.Text,
            Status = CourseStatusPicker.SelectedItem.ToString(),
            InstructorsName = InstructorsName.Text,
            InstructorsPhone = InstructorsPhone.Text,
            InstructorsEmail = InstructorsEmail.Text,
            StartNotification = StartNotification.IsToggled,
            EndNotification = EndNotification.IsToggled,
            StartDate = StartDatePicker.Date,
            EndDate = EndDatePicker.Date,
            Notes = NotesEditor.Text
        };

        await DatabaseService.UpdateEntityAsync(course);

        await Navigation.PopAsync();
    }

    private async void CancelCourse_Clicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    private async void DeleteCourse_Clicked(object sender, EventArgs e)
    {
        var answer = await DisplayAlert("Delete?", "Delete Course and Related Assessments?", "Yes", "No");
        if (answer == true)
        {
            var id = int.Parse(CourseId.Text);
            await DatabaseService.RemoveCourse(id);
        }
        else
        {
            await DisplayAlert("Canceled", "Deletion Canceled", "OK");
        }

        await Navigation.PopAsync();
    }

    private async void AddAssessment_Clicked(object sender, EventArgs e)
    {
        var courseId = Int32.Parse(CourseId.Text);
        await Navigation.PushAsync(new AssessmentAdd(courseId));
    }

    private async void AssessmentCollectionView_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        var assessment = e.CurrentSelection.FirstOrDefault() as Assessment;
        if (assessment != null)
        {
            await Navigation.PushAsync(new AssessmentEdit(assessment));
        }
    }

    private async void ShareButton_Clicked(object sender, EventArgs e)
    {
        var text = NotesEditor.Text;
        if (text is null)
        {
            await DisplayAlert("Missing Notes", "Please enter course notes to be shared.", "OK");
            return;
        }
        await Share.RequestAsync(new ShareTextRequest
        {
            Text = text,
            Title = "Share Course Info"
        });
    }

    private bool _isElementVisible;
    public bool IsElementVisible
    {
        get => _isElementVisible;
        set
        {
            if (_isElementVisible != value)
            {
                _isElementVisible = value;
                OnPropertyChanged(); // Notify UI of change
            }
        }
    }


}