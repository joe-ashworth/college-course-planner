using Courses.Services;
using Courses.Models;
using System.Collections.ObjectModel;

namespace Courses.Views;

public partial class Search : ContentPage
{
    public ObservableCollection<Course> Courses { get; set; } = new ObservableCollection<Course>();
    public Search()
    {
        InitializeComponent();
        TermCollectionView.ItemsSource = Courses;
    }

    private async void OnSearchTextChanged(object sender, TextChangedEventArgs e)
    {
        var searchString = e.NewTextValue;

        if (string.IsNullOrWhiteSpace(searchString))
        {
            Courses.Clear();
            return;
        }

        var courses = await DatabaseService.GetCourses(searchString);

        Courses.Clear();
        foreach (var course in courses)
        {
            Courses.Add(course);
        }
    }

    private async void Back_Clicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }
}