using Courses.Services;
using Courses.Models;

namespace Courses.Views;

public partial class TermAdd : ContentPage
{
    public TermAdd()
    {
        InitializeComponent();
    }

    private async void SaveTerm_Clicked(object sender, EventArgs e)
    {
        // Trim inputs
        string termTitle = TermTitle.Text?.Trim() ?? string.Empty;

        if (!ValidationService.IsValidTitle(termTitle))
        {
            await DisplayAlert("Title Error", "Please enter a valid title.", "OK");
            return;
        }

        if (StartDatePicker.Date >= EndDatePicker.Date)
        {
            await DisplayAlert("Invalid Dates", "The start date must precede the end date.", "OK");
            return;
        }

        await DatabaseService.InsertEntityAsync(
            new Term { 
                Title = termTitle, 
                StartDate = StartDatePicker.Date, 
                EndDate = EndDatePicker.Date 
            }
        );

        await Navigation.PopAsync();
    }

    private async void CancelTerm_Clicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }
}