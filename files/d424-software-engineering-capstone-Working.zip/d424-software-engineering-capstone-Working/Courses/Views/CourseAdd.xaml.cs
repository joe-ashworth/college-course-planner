using Courses.Models;
using Courses.Services;

namespace Courses.Views;

public partial class CourseAdd : ContentPage
{
    private readonly int _selectedTermId;

    public CourseAdd()
    {
        InitializeComponent();
        LoadStatusOptions();
    }

    public CourseAdd(int termId)
    {
        InitializeComponent();
        _selectedTermId = termId;
        LoadStatusOptions();
    }

    private async void LoadStatusOptions()
    {
        var statusOptions = await DatabaseService.GetStatusOptionsAsync();
        CourseStatusPicker.ItemsSource = statusOptions.ToList();
    }

    async void SaveCourse_Clicked(object sender, EventArgs e)
    {
        // Trim inputs
        string courseTitle = CourseTitle.Text?.Trim() ?? string.Empty;
        string instructorsName = InstructorsName.Text?.Trim() ?? string.Empty;
        string instructorsPhone = InstructorsPhone.Text?.Trim() ?? string.Empty;
        string instructorsEmail = InstructorsEmail.Text?.Trim() ?? string.Empty;
        string notes = NotesEditor.Text?.Trim() ?? string.Empty;

        int currentCount = await DatabaseService.GetCourseCountAsync(_selectedTermId); // Should not be necessary
        if (currentCount >= 6)
        {
            await DisplayAlert("Maximum Courses Reached", "Only 6 courses are allowed per term.", "OK");
            return;
        }

        if (!ValidationService.IsValidTitle(courseTitle))
        {
            await DisplayAlert("Title Error", "Please enter a valid title.", "OK");
            return;
        }

        if (CourseStatusPicker.SelectedIndex == -1)
        {
            await DisplayAlert("Missing Status", "Please select a status.", "OK");
            return;
        }

        if (!ValidationService.IsValidName(instructorsName))
        {
            await DisplayAlert("Invalid Name", "Please enter a valid name.", "OK");
            return;
        }

        if (!ValidationService.IsValidPhone(instructorsPhone))
        {
            await DisplayAlert("Invalid Phone", "Please enter valid phone number.", "OK");
            return;
        }

        if (!ValidationService.IsValidEmail(instructorsEmail))
        {
            await DisplayAlert("Invalid Email", "Please enter a valid email address.", "OK");
            return;
        }

        await DatabaseService.InsertEntityAsync(
            new Course
            {
                TermId = _selectedTermId,
                Title = courseTitle,
                Status = CourseStatusPicker.SelectedItem.ToString(),
                InstructorsName = instructorsName,
                InstructorsPhone = instructorsPhone,
                InstructorsEmail = instructorsEmail,
                StartDate = StartDatePicker.Date,
                EndDate = EndDatePicker.Date,
                StartNotification = StartNotification.IsToggled,
                EndNotification = EndNotification.IsToggled,
                Notes = notes,
                CreationDate = DateTime.Now
            }
        );

        await Navigation.PopAsync();
    }

    private async void CancelCourse_Clicked(object sender, EventArgs e)
    {
        await Navigation.PopAsync();
    }

    private async void Home_Clicked(object sender, EventArgs e)
    {
        await Navigation.PopToRootAsync();
    }
}