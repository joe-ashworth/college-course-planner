﻿using Courses.Views;

namespace Courses
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            var termListPage = new TermList();
            MainPage = new NavigationPage(termListPage)
            {
                BarBackgroundColor = Color.FromArgb("#00558c"),
                BarTextColor = Colors.White
            };

            ShowLoginPage();
        }

        private async void ShowLoginPage()
        {
            var loginPage = new LoginPage();
            await MainPage.Navigation.PushModalAsync(loginPage);
        }

    }
}